﻿namespace FinalVer_Assignment_2
{
    partial class AddUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            label1 = new Label();
            label3 = new Label();
            btnBack = new Button();
            panel1 = new Panel();
            txtPostal = new TextBox();
            label9 = new Label();
            txtState = new TextBox();
            label8 = new Label();
            txtCity = new TextBox();
            label7 = new Label();
            txtAddress = new TextBox();
            label6 = new Label();
            txtPhone = new TextBox();
            btnPass = new Button();
            lblPassword = new Label();
            btnID = new Button();
            btnAddUser = new Button();
            label4 = new Label();
            txtLName = new TextBox();
            label2 = new Label();
            lblFName = new Label();
            txtFName = new TextBox();
            lblLName = new Label();
            txtEmail = new TextBox();
            lblEmail = new Label();
            lblPass = new Label();
            lblID = new Label();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.Controls.Add(label1);
            panel2.Controls.Add(label3);
            panel2.Location = new Point(165, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(544, 113);
            panel2.TabIndex = 29;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(48, 9);
            label1.Name = "label1";
            label1.Size = new Size(448, 45);
            label1.TabIndex = 0;
            label1.Text = "Library Management System";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(184, 68);
            label3.Name = "label3";
            label3.Size = new Size(177, 32);
            label3.TabIndex = 7;
            label3.Text = "Add New User";
            // 
            // btnBack
            // 
            btnBack.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnBack.Location = new Point(22, 137);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(103, 32);
            btnBack.TabIndex = 31;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(txtPostal);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(txtState);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(txtCity);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(txtAddress);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txtPhone);
            panel1.Controls.Add(btnPass);
            panel1.Controls.Add(lblPassword);
            panel1.Controls.Add(btnID);
            panel1.Controls.Add(btnAddUser);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(txtLName);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(lblFName);
            panel1.Controls.Add(txtFName);
            panel1.Controls.Add(lblLName);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(lblEmail);
            panel1.Controls.Add(lblPass);
            panel1.Controls.Add(lblID);
            panel1.Location = new Point(165, 168);
            panel1.Name = "panel1";
            panel1.Size = new Size(544, 562);
            panel1.TabIndex = 32;
            // 
            // txtPostal
            // 
            txtPostal.Location = new Point(175, 434);
            txtPostal.Name = "txtPostal";
            txtPostal.Size = new Size(290, 23);
            txtPostal.TabIndex = 41;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label9.Location = new Point(62, 434);
            label9.Name = "label9";
            label9.Size = new Size(96, 21);
            label9.TabIndex = 40;
            label9.Text = "Postal Code";
            // 
            // txtState
            // 
            txtState.Location = new Point(175, 385);
            txtState.Name = "txtState";
            txtState.Size = new Size(290, 23);
            txtState.TabIndex = 39;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label8.Location = new Point(96, 385);
            label8.Name = "label8";
            label8.Size = new Size(47, 21);
            label8.TabIndex = 38;
            label8.Text = "State";
            // 
            // txtCity
            // 
            txtCity.Location = new Point(175, 339);
            txtCity.Name = "txtCity";
            txtCity.Size = new Size(290, 23);
            txtCity.TabIndex = 37;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label7.Location = new Point(96, 337);
            label7.Name = "label7";
            label7.Size = new Size(39, 21);
            label7.TabIndex = 36;
            label7.Text = "City";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(175, 292);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(290, 23);
            txtAddress.TabIndex = 35;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(79, 290);
            label6.Name = "label6";
            label6.Size = new Size(71, 21);
            label6.TabIndex = 34;
            label6.Text = "Address ";
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(175, 243);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(290, 23);
            txtPhone.TabIndex = 33;
            // 
            // btnPass
            // 
            btnPass.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnPass.Location = new Point(336, 61);
            btnPass.Name = "btnPass";
            btnPass.Size = new Size(95, 24);
            btnPass.TabIndex = 32;
            btnPass.Text = "Generate Pass";
            btnPass.UseVisualStyleBackColor = true;
            btnPass.Click += btnPass_Click;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblPassword.Location = new Point(175, 61);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(155, 21);
            lblPassword.TabIndex = 31;
            lblPassword.Text = "id //auto generated ";
            // 
            // btnID
            // 
            btnID.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnID.Location = new Point(336, 20);
            btnID.Name = "btnID";
            btnID.Size = new Size(95, 24);
            btnID.TabIndex = 30;
            btnID.Text = "Generate ID";
            btnID.UseVisualStyleBackColor = true;
            btnID.Click += btnID_Click;
            // 
            // btnAddUser
            // 
            btnAddUser.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddUser.Location = new Point(184, 492);
            btnAddUser.Name = "btnAddUser";
            btnAddUser.Size = new Size(158, 44);
            btnAddUser.TabIndex = 29;
            btnAddUser.Text = "Add User";
            btnAddUser.UseVisualStyleBackColor = true;
            btnAddUser.Click += btnAddUser_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(71, 152);
            label4.Name = "label4";
            label4.Size = new Size(87, 21);
            label4.TabIndex = 27;
            label4.Text = "Last Name";
            // 
            // txtLName
            // 
            txtLName.Location = new Point(175, 152);
            txtLName.Name = "txtLName";
            txtLName.Size = new Size(290, 23);
            txtLName.TabIndex = 28;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(84, 20);
            label2.Name = "label2";
            label2.Size = new Size(63, 21);
            label2.TabIndex = 22;
            label2.Text = "User ID";
            // 
            // lblFName
            // 
            lblFName.AutoSize = true;
            lblFName.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblFName.Location = new Point(69, 104);
            lblFName.Name = "lblFName";
            lblFName.Size = new Size(89, 21);
            lblFName.TabIndex = 14;
            lblFName.Text = "First Name";
            // 
            // txtFName
            // 
            txtFName.Location = new Point(175, 104);
            txtFName.Name = "txtFName";
            txtFName.Size = new Size(290, 23);
            txtFName.TabIndex = 15;
            // 
            // lblLName
            // 
            lblLName.AutoSize = true;
            lblLName.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblLName.Location = new Point(96, 196);
            lblLName.Name = "lblLName";
            lblLName.Size = new Size(51, 21);
            lblLName.TabIndex = 16;
            lblLName.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(175, 194);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(290, 23);
            txtEmail.TabIndex = 17;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblEmail.Location = new Point(41, 243);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(117, 21);
            lblEmail.TabIndex = 18;
            lblEmail.Text = "Phone Number";
            // 
            // lblPass
            // 
            lblPass.AutoSize = true;
            lblPass.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblPass.Location = new Point(79, 61);
            lblPass.Name = "lblPass";
            lblPass.Size = new Size(79, 21);
            lblPass.TabIndex = 20;
            lblPass.Text = "Password";
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblID.Location = new Point(175, 20);
            lblID.Name = "lblID";
            lblID.Size = new Size(155, 21);
            lblID.TabIndex = 23;
            lblID.Text = "id //auto generated ";
            // 
            // AddUserForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(862, 755);
            Controls.Add(panel1);
            Controls.Add(btnBack);
            Controls.Add(panel2);
            Name = "AddUserForm";
            Text = "AddUserForm";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Label label1;
        private Label label3;
        private Button btnBack;
        private Panel panel1;
        private Button btnPass;
        private Label lblPassword;
        private Button btnID;
        private Button btnAddUser;
        private Label label4;
        private TextBox txtLName;
        private Label label2;
        private Label lblFName;
        private TextBox txtFName;
        private Label lblLName;
        private TextBox txtEmail;
        private Label lblEmail;
        private Label lblPass;
        private Label lblID;
        private TextBox txtCity;
        private Label label7;
        private TextBox txtAddress;
        private Label label6;
        private TextBox txtPhone;
        private TextBox txtPostal;
        private Label label9;
        private TextBox txtState;
        private Label label8;
    }
}