# LibraryApp
Library App 
Key Features:
User Registration and Login System: Users can register themselves to borrow books.
Book Management System for Admin: Add new books, update book details, and delete books.
Borrow and Return Feature: Users can borrow available books and return them.
Overdue Books Tracking: Admin can see a list of books that are overdue.
Search Books: Users and Admin can search books by title, author, or genre.
Book Reservation: Users can reserve a book if it's currently borrowed.
Implementation:
GUI/Windows form and controls: Use different forms for user registration, login, book management, and borrowing/returning books.
